class wholecode{
    
//String section1="";
String s11 = "import java.applet.*;\nimport java.awt.*;\nimport java.util.*;\n\n";
String s12 = "/*\nAuthor:King Yip Chan\nSimple Graph Drawer\n*/\n\n";
String s13 = "public class simple extends Applet {\n\n\tVector nodes = new Vector(); //storage for nodes\n\tVector lines = new Vector(); //storage for edges\n\t";
String s14 = "int last_x=0, last_y=0, count =0, cnode=0, cnode2=0, point2=0;\n\tint clicked=0;\n\tboolean selected = false, selectedline = false, selected2=false;\n\tboolean front=false, back =false, addnode = false, addline = false;\n\tButton add_button, added_button, clear_button;\n\tButton showcode;\n\tTextArea textarea;\n\t";
//String section2="";
String s21 = "\n\tpublic void init() {\n\t\t//Here is where all the components such as buttons are intialised\n\t\tthis.setLayout(null);\n\t\tthis.setSize(800,500);\n\t\tthis.setBackground(Color.gray);\n\n\n\t\tadd_button = new Button(\"     Add/Select Node     \");\n\t\tadd_button.setBounds(10,10, 110,23);\n\t\tadd_button.setFont(new Font(\"Dialog\", Font.PLAIN, 12));\n\t\t";
String s22 = "add_button.setForeground(Color.black);\n\t\tadd_button.setBackground(Color.lightGray);\n\t\tthis.add(add_button);\n\n\t\tadded_button = new Button(\"     Add/Select Edge     \");\n\t\tadded_button.setBounds(123,10, 110,23);\n\t\tadded_button.setFont(new Font(\"Dialog\", Font.PLAIN, 12));\n\t\tadded_button.setForeground(Color.black);\n\t\tadded_button.setBackground(Color.lightGray);\n\t\t";
String s23 = "this.add(added_button);\n\n\t\tclear_button = new Button(\"Clear\");\n\t\tclear_button.setBounds(237,10, 80,23);\n\t\tclear_button.setFont(new Font(\"Dialog\", Font.PLAIN, 12));\n\t\tclear_button.setForeground(Color.black);\n\t\tclear_button.setBackground(Color.lightGray);\n\t\tthis.add(clear_button);\n\n\t\tshowcode = new Button(\"showcode\");\n\t\tshowcode.setBounds(320,10, 110,23);\n\t\t";
String s24 = "showcode.setFont(new Font(\"Dialog\", Font.PLAIN, 12));\n\t\tshowcode.setForeground(Color.black);\n\t\tshowcode.setBackground(Color.lightGray);\n\t\tthis.add(showcode);\n\t}\n";


    public String section1() {
        String section1= s11+s12+s13+s14;
        return section1;
    }
    
    public String section2() {
        String section2=s21+s22+s23+s24;
        return section2;
    }
    
    public String allsection() {
        String allsection = section1()+section2();
        return allsection;
    }

}