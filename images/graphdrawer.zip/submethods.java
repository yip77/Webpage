import java.util.*;

class submethods {

    /*
    Date: 5th September 2000
    Name: Simple Graph Drawer

    An object which holds methods which are used in the simple class
    it is called from the simple class and each method return an object
    of its type.
    */

    public int[] selectalllines(Vector lines, int x, int y) {
        //selects the x,y
        int[] a = new int[100]; int backw=0;
        for(int i=0; i<lines.size(); i++) {
            lines l = (lines)lines.elementAt(i);
            if(x == l.x && y == l.y) {
                if(i == 0) { a[backw]= -1; backw++; }
                else { a[backw]=i; backw++; }
            }
        }
        return a;
    }


    public int[] selectalllines2(Vector lines, int x, int y) {
        //selects the x2, y2
        int[] ab = new int[100]; int frontw=0;
        for(int i=0; i<lines.size(); i++) {
            lines l = (lines)lines.elementAt(i);
            if(x == l.x2 && y == l.y2) {
               if(i == 0) { ab[frontw] = -1; frontw++; }
               else { ab[frontw]=i; frontw++; }
            }
        }
        return ab;
    }

    public String print(int[]a) {
        String z ="";
        for(int i=0; i<5; i++) {
            z = z+ ", "+a[i];
        }
        return z;
    }


}