import java.applet.*;
import java.awt.*;
import java.util.*;

/*
Date: 5th September 2000
Name: Simple Graph Drawer
*/

public class simple extends Applet {

    Vector nodes = new Vector(); //storage for nodes
    Vector lines = new Vector(); //storage for edges
    int last_x=0, last_y=0, count =0, cnode=0, cnode2=0, point2=0;
    int clicked=0;
    boolean selected = false, selectedline = false, selected2=false;
    boolean front=false, back =false, addnode = false, addline = false;
	Button add_button, added_button, clear_button;
    Button showcode;
    TextArea textarea;
    //Label b;


    public void init() {
        //Here is where all the components such as buttons are intialised
        this.setLayout(null);
        this.setSize(800,500);
        this.setBackground(Color.gray);

    	add_button = new Button("     Add/Select Node     ");
    	add_button.setBounds(10,10, 110,23);
    	add_button.setFont(new Font("Dialog", Font.PLAIN, 12));
    	add_button.setForeground(Color.black);
        add_button.setBackground(Color.lightGray);
        this.add(add_button);

        added_button = new Button("     Add/Select Edge     ");
        added_button.setBounds(123,10, 110,23);
        added_button.setFont(new Font("Dialog", Font.PLAIN, 12));
    	added_button.setForeground(Color.black);
       	added_button.setBackground(Color.lightGray);
        this.add(added_button);

        clear_button = new Button("Clear");
        clear_button.setBounds(237,10, 80,23);
        clear_button.setFont(new Font("Dialog", Font.PLAIN, 12));
    	clear_button.setForeground(Color.black);
       	clear_button.setBackground(Color.lightGray);
        this.add(clear_button);
        /*
        showcode = new Button("showcode");
        showcode.setBounds(320,10, 110,23);
        showcode.setFont(new Font("Dialog", Font.PLAIN, 12));
    	showcode.setForeground(Color.black);
       	showcode.setBackground(Color.lightGray);
        this.add(showcode);
        */
}

    public boolean withinnode(Vector nodes, int x, int y) {
        /*methods which checks mouse is within a node & return true/false
        also it saves the index postion of that node in cnode & cnode2
        variables*/
        for(int i=0; i<nodes.size(); i++) {
    	    nodes n = (nodes)nodes.elementAt(i);
            if(x > n.x && x < n.x+20) { //checks the x cordinates
      	        if(y > n.y && y <n.y +20) { //checks the y cordinates
      	            cnode=i; cnode2=i; return true; //return true if within node
      	        }
      	    }
      	}
        return false; //else it will be false
    }

    public boolean clickline(Vector lines, int x, int y) {
        /*checks if the current mouse position is within a edge and
        that is known when selected either ends of an edge.*/
        for(int i=0; i<lines.size(); i++) {
            lines l = (lines)lines.elementAt(i);
            if(x > l.x-1 && x < l.x+1) {//checks if within 1st point of edge
                if(y > l.y-1 && y > l.y+1){
                    point2=i; front=true; back=false; return true;
                }
            }
            if(x > l.x2-1 && x < l.x2+1) {//checks if within 2st point of edge
                if(y > l.y2-1 && y > l.y2+1){
                    point2=i; back=true; front=false; return true;
                }
            }
        }
        return false;
    }

    public boolean mouseUp (Event e, int x, int y) {
        /*all relating mouse up events such as when moving an edge to connect
        to other nodes or adding a new edge*/
        if(selectedline == false) { //if not edges selected than draw a new one
            nodes n = (nodes)nodes.elementAt(cnode);
            lines.setElementAt(new lines(last_x, last_y, n.x, n.y),count);
            count++;
        }
        if(addline == true)  {
            //if selected an edge and from method clickline, will show which end of the edge is selected
            lines l = (lines)lines.elementAt(point2);
            if(selectedline == true && front == true) { //if start of edge
      	        nodes point = (nodes)nodes.elementAt(cnode);
   	            lines.setElementAt(new lines(point.x, point.y, l.x2, l.y2),point2);
            }
            else if(selectedline == true && back == true) { //if end of edge
                nodes point = (nodes)nodes.elementAt(cnode);
   	            lines.setElementAt(new lines(l.x, l.y, point.x, point.y),point2);
            }
        }
        return true;
    }

    public boolean mouseDown (Event e, int x, int y) {
        /*all relating mouse down events */
        if(addnode == true && selected == false) {
	        //if add node button is selected & current mouse point is not within a node
	        nodes.addElement(new nodes(x, y)); //add a new node
			repaint();
			return true;
		}
		if(withinnode(nodes, x, y) == false) {
		    //if the current mouse point is not within node, do not add edge
            lines.removeElementAt(count);
        }
		else if(addline == true && selectedline == false) {
		    last_x=x; last_y=y;
	        if(withinnode(nodes, x, y) == true) {
	            //first stage of drawing an edge when the mouse button is pressed
	            nodes firstpoint = (nodes)nodes.elementAt(cnode2);
	            last_x=firstpoint.x; last_y=firstpoint.y;
	        }
	        lines.addElement(new lines(last_x,last_y,x,y));
		}
		repaint();
		return true;
    }

    public boolean mouseMove (Event e, int x, int y) {
        /*all relating mouse move events */
        if(clickline(lines, x, y) == true) {
            //when mouse is moved over any ends of the edge
            added_button.setLabel("Selected Edge");//change button label to "Selected Edge"
            selectedline=true;//selected an edge is true
            repaint();
            return true;
        }
        if(withinnode(nodes, x, y) ==true) {
            //when mouse is moved over any node
            add_button.setLabel("Selected Node");//change button label to "Selected node"
            selected=true;//therefore selected a node is true
            repaint();
            return true;
        }
        add_button.setLabel("     Add/Select Node     "); //if not set labels back to normal
        added_button.setLabel("     Add/Select Edge     ");
        selectedline=false;
        selected=false;
        repaint();
        return false;
    }

    public boolean mouseDrag(Event e, int x, int y) {
        /*all relating mouse up events. If edge 0 that it is stored as -1
        */
        if(withinnode(nodes, x, y) == true) { repaint();}
        if(addnode == true) {
            if(selected == true) {
                submethods sm = new submethods(); //invoking method in submethods class
                nodes find = (nodes)nodes.elementAt(cnode);
                //finds all the edges connected to which node
                int[]one = sm.selectalllines(lines, find.x, find.y);
                int[]two = sm.selectalllines2(lines, find.x, find.y);
                if(one[0] == 0 && two[0] == 0) { //if no edges connected
                    nodes.setElementAt(new nodes(x,y), cnode);
                    repaint();
                }
                /******dragging of nodes with edges connected(start)******/
                else {
                    for(int i=0; i<100; i++) {
                        //This is for the connection of starting point of edge 0
                        if(one[0] == -1) { //if edge 0
                            nodes.setElementAt(new nodes(x, y), cnode);
                            if(one[1] !=0) {//if index position 1 is not empty
                                for(int j=0; j<100; j++) {
                                    if(one[j] == -1) {one[j]=0;}
                                        lines l = (lines)lines.elementAt(one[j]);
                                        lines.setElementAt(new lines(x, y, l.x2, l.y2), one[j]);
                                        repaint();
                                }
                            }
                            else if(two[0] !=0) { //if index position 0 of second point is not empty
                                for(int j=0; j<100; j++) {
                                    if(one[j] == -1) {one[j]=0;}
                                    if(one[j] == 0 && two[j] == 0) {break;}
                                        lines l = (lines)lines.elementAt(one[j]);
                                        lines li = (lines)lines.elementAt(two[j]);
                                        lines.setElementAt(new lines(x, y, l.x2, l.y2), one[j]);
                                        lines.setElementAt(new lines(li.x, li.y, x, y), two[j]);
                                        repaint();
                                }
                            }
                            else {//only just selected edge 0
                                lines l2 = (lines)lines.elementAt(0);
                                lines.setElementAt(new lines(x, y, l2.x2, l2.y2), 0);
                                repaint();
                            }
                        }
                        //This is for the connection of finishing point of edge 0
                        else if(two[0] == -1) {//if edge 0
                            nodes.setElementAt(new nodes(x, y), cnode);
                            if(two[1] !=0) {//if index position 1 is not empty
                                for(int j=0; j<100; j++) {
                                    if(two[j] == -1) {two[j]=0;}
                                        lines l = (lines)lines.elementAt(two[j]);
                                        lines.setElementAt(new lines(l.x, l.y, x, y), two[j]);
                                        repaint();
                                    }
                            }
                            else if(one[0] !=0) {//if index position 0 of second point is not empty
                                for(int j=0; j<100; j++) {
                                    if(two[j] == -1) {two[j]=0;}
                                    if(one[j] == 0 && two[j] == 0) {break;}
                                        lines l = (lines)lines.elementAt(one[j]);
                                        lines li = (lines)lines.elementAt(two[j]);
                                        lines.setElementAt(new lines(x, y, l.x2, l.y2), one[j]);
                                        lines.setElementAt(new lines(li.x, li.y, x, y), two[j]);
                                        repaint();
                                }
                            }
                            else { //only just selected edge 0
                                lines l4 = (lines)lines.elementAt(0);
                                lines.setElementAt(new lines(l4.x, l4.y, x, y), 0);
                                repaint();
                            }
                        }
                        //This is for the connection of finishing point starting points for edge 1 to n
                        if(one[i] != 0 || two[i] != 0) {
                            nodes.setElementAt(new nodes(x, y), cnode);
                            lines l5 = (lines)lines.elementAt(one[i]);
                            lines l6 = (lines)lines.elementAt(two[i]);
                            if(two[i] ==0) {
                                lines.setElementAt(new lines(x, y, l5.x2, l5.y2), one[i]);
                                repaint();
                            }
                            else if(one[i] ==0) {
                                lines.setElementAt(new lines(l6.x, l6.y, x, y), two[i]);
                                repaint();
                            }
                            else if(one[i] != 0 && two[i] !=0){
                                lines.setElementAt(new lines(x, y, l5.x2, l5.y2), one[i]);
                                lines.setElementAt(new lines(l6.x, l6.y, x, y), two[i]);
                                repaint();
                            }
                            repaint();
                        }
                    }
                }
                /******dragging of nodes with edges connected(finish)******/
                repaint();
                return true;
            }
      	}
      	else if (addline == true) {
      	    //section where the lines is being dragged
            if(selectedline == true) {
          	    lines l = (lines)lines.elementAt(point2);
          	    if(front == true) {//redraws the start point of edge
       	            lines.setElementAt(new lines(x, y, l.x2, l.y2),point2);
       	            repaint();
     	        }
       	        else if(back == true) {//redraws the finish point of edge
                   lines.setElementAt(new lines(l.x, l.y, x, y),point2);
                   repaint();
       	        }
       	    }
      	    else if(withinnode(nodes, x, y) == true) { selected2=true; }
      	    lines.setElementAt(new lines(last_x,last_y, x, y),count);
      	    repaint();
      	}
      	repaint();
        return true;
    }

    public boolean action(Event event, Object arg) {
        //all relating button action when each one is clicked
        if (event.target == add_button) {
      		add_button.setFont(new Font("Dialog", Font.BOLD, 12));
      		added_button.setFont(new Font("Dialog", Font.PLAIN, 12));
			addnode = true; addline = false; return true;
		}
		else if(event.target == added_button) {
		    added_button.setFont(new Font("Dialog", Font.BOLD, 12));
		    add_button.setFont(new Font("Dialog", Font.PLAIN, 12));
			addnode = false; addline = true; return true;
		}
		else if(event.target == clear_button) {
		    added_button.setFont(new Font("Dialog", Font.PLAIN, 12));
  		    add_button.setFont(new Font("Dialog", Font.PLAIN, 12));
		    addnode = false; addline = false; count=0;
		    nodes.removeAllElements(); lines.removeAllElements();
		    repaint();
			return true;
		}
		/*else if(event.target == showcode) {
		    if(clicked == 0) {
      		    showcode.setFont(new Font("Dialog", Font.BOLD, 12));
      		    wholecode wh = new wholecode();
      		    textarea = new TextArea(wh.allsection());
    	        textarea.setFont(new Font("Dialog", Font.PLAIN, 10));
                textarea.setBounds(14, 40, 400, 200);
                this.add(textarea);
                clicked++;
            }
            else if(clicked == 1) {
                showcode.setFont(new Font("Dialog", Font.PLAIN, 12));
                this.remove(textarea);
                clicked =0;
            }
	        return true;
		}*/
		else return super.action(event, arg);
    }

    public void paint(Graphics g) {
        /*paint method is where it draws all the elements stored in the vectors
        onto the screen. This is done every time the repaint method (repaint())
        is called.*/
        for(int i=0; i<nodes.size(); i++) {
            nodes n = (nodes)nodes.elementAt(i);
            g.drawOval(n.x-10, n.y-10, 20, 20);
            if(selected == true) {//make node different if selected
                nodes n1 = (nodes)nodes.elementAt(cnode);
                g.setColor(Color.red);
                g.drawOval(n1.x-10, n1.y-10, 20, 20);
                g.fillOval(n1.x-10, n1.y-10, 20, 20);//fill circle with red
                g.setColor(Color.blue);
                g.drawString("node "+cnode, n1.x+15, n1.y+10); //indicate which node
                g.setColor(Color.black);
            }
        }
        for(int i=0; i<lines.size(); i++) {
            lines l = (lines)lines.elementAt(i);
            g.setColor(Color.black);
            g.drawLine(l.x, l.y, l.x2, l.y2);
            if(selectedline == true) {
                lines l1 = (lines)lines.elementAt(point2);
                g.setColor(Color.red);//highlight select edge
                g.drawLine(l1.x, l1.y, l1.x2, l1.y2);
                g.setColor(Color.black);
                g.drawString("edge "+point2, l1.x+((l1.x2-l1.x)/2), l1.y+((l1.y2-l1.y)/2));
                g.setColor(Color.blue);//indicate the two end points
                g.drawRect(l1.x-3, l1.y-3, 6,6);
                g.drawRect(l1.x2-3, l1.y2-3, 6,6);
            }
        }
    }
	//{{DECLARE_CONTROLS
	//}}
}