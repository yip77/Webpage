class nodes {
    /*
    Date: 5th September 2000
    Name: Simple Graph Drawer

    object called nodes which holds
    variables x and y
    */
    int x;
    int y;

    nodes (int x, int y) {
        this.x=x;
        this.y=y;
    	
    }
	
}
