class lines {
    /*
    Date: 5th September 2000
    Name: Simple Graph Drawer

    object called lines which holds the positions of
    the edges drawn on screen. x and y are the starting point
    and x2 and y2 are the finishing point*/
    int x;
    int y;
    int x2;
    int y2;

    lines (int x, int y, int x2, int y2) {
        this.x = x;
        this.y = y;
        this.x2 = x2;
        this.y2 = y2;
    		//{{INIT_CONTROLS
		//}}
}
	//{{DECLARE_CONTROLS
	//}}
}
